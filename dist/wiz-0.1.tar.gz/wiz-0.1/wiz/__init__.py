#!/usr/bin/env python
#coding:utf-8
# Author        : tuxpy
# Email         : q8886888@qq.com.com
# Last modified : 2015-11-02 10:58:44
# Filename      : __init__.py
# Description   : 
from __future__ import print_function, unicode_literals

version = '0.1'

