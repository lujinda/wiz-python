#!/usr/bin/env python
#coding:utf-8
# Author        : tuxpy
# Email         : q8886888@qq.com.com
# Last modified : 2015-11-02 10:38:09
# Filename      : config.py
# Description   : 
from __future__ import print_function, unicode_literals

host = 'https://note.wiz.cn'
version = '5'
client_type = 'web2.0'

